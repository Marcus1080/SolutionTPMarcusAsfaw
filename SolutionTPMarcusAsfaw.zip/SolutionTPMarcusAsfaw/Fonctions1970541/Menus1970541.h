#pragma once
//But : Votre petit cousin est fascin� par les formes g�om�triques. A chaque fois que vous le rencontrez, il vous demande
//de lui dessiner des carr�s, des rectangles, des triangles, des losanges.Quelques fois, il les veut plein, d�autres fois
//vides, il les veut de tailles diff�rentes, des petits, des gros.Vous d�cidez d��crire un programme en C++ qui r�pondra
//� tous les caprices de votre petit cousin et qu�enfin vous retrouviez un peu la paix !
//Auteur : Marcus Asfaw
//Date : Le 17 Novembre 2020 (date de remise)



//But : 
//Auteur: Marcus Asfaw
//Date : Le 3 novembre 2020




//La liste des prototypes permetttant d'afficher et de valider les choix faits dans les menus
int afficherMenu(int choixForme); //Pour afficher le premier menu pour le choix de la forme 
int afficherMenu2(int choixRemplissage); //Pour afficher le deuxi�me menu pour choisir le Remplissage 
int validerMenu(); //Pour valider le menu assurer qu'il ne peux pas arr�ter a cause d'une commande �trange 
//int genererNombreAleatoire();