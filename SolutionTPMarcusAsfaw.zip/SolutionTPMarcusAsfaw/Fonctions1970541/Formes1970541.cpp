
//But : Votre petit cousin est fascin� par les formes g�om�triques. A chaque fois que vous le rencontrez, il vous demande
//de lui dessiner des carr�s, des rectangles, des triangles, des losanges.Quelques fois, il les veut plein, d�autres fois
//vides, il les veut de tailles diff�rentes, des petits, des gros.Vous d�cidez d��crire un programme en C++ qui r�pondra
//� tous les caprices de votre petit cousin et qu�enfin vous retrouviez un peu la paix !
//Auteur : Marcus Asfaw
//Date : Le 17 Novembre 2020 (date de remise)

#include "Formes1970541.h" //On ajoute les deux .h les formes et les menus 
#include "Menus1970541.h"
#include <iostream>
using namespace std;

int traiterRectangle(int Hauteur, int Largeur)//J'ai commencer par le rectangle il a une largeur et une hauteur 
{

    std::cout << "Veuillez entrer la hauteur desirer --> ";//Je commence par demander la hauteur
    cin >> Hauteur;
    if (Hauteur > 0)//Si la hauteur est plus que 0 donc un bon chiffre 
    {
        std::cout << "Veuillez entrer la largeur desirer --> ";//On passe a demander la largeur d�sirer pour afficher la forme 
        cin >> Largeur;
        if (Largeur > 0)//Si largeur est bien plus que 0
        {
            dessinerRectangle;//On passe a dessiner le rectangle 
        }
        else//Sinon
        {
            std::cout << "Erreur veuillez entrer un chiffre raisonnable ";//On affiche un message d'erreur
            return Largeur;//Et on retourne la largeur 
        }
    }
    else //Mais si la hauteur est �gale a 0 ou moins que 0 
    {
        std::cout << "Erreur veuillez entrer un chiffre raisonnable "; //On affiche ce message d'erreur 
        return Hauteur;//Puis on retourne la hauteur 

    }

    
}

int traiterCarre(int Hauteur)//Le m�me principe pour le carr�
{
    std::cout << "Veuillez entrer la hauteur desirer --> ";//demande la hauteur puis on le confirme plus tard
    cin >> Hauteur;
        if (Hauteur > 0) // Pour le carre on demande simplement la hauteur puisque les carre on tous les m�me c�t�s pareils
        {
            dessinerCarre;//Si la largeur est plus grande que 0 on passe a dessiner 

        }
        else//Sinon
        {
            std::cout << "Erreur veuillez entrer un chiffre raisonnable "; //On affiche ce message d'erreur 
            return Hauteur;// Puis on retourne la hauteur 
        }
    
}

int traiterTriangle(int Hauteur)//pour le triangle c'est diff�rent puisque le trinagle ne peux pas avoir de largeur 
{
    std::cout << "Veuillez entrer la hauteur desirer --> ";//Donc on fais le m�me processus
    cin >> Hauteur;//Mais seulement pour la hauteur pas de largeur
    if (Hauteur > 0)//Si la largeur est un chiffre correct 
    {
        dessinerTriangle1();//On peux directement le dessiner 
    }
    else//Puis sinon on affiche le message d'erreur 
    {
        std::cout << "Erreur veuillez entrer un chiffre raisonnable ";
        return Hauteur;//On retourne la forme
    }
    return 0;
}

int traiterLosange(int Hauteur)//Pour traiter le losange vu qu'on dessine plusieurs triangles
{
    cout << "Veuillez entrer la hauteur desirer --> ";//On va aussi simplement demander la hauteur pas besoin de largeur
    cin >> Hauteur;//On indique la hauteur ici
    if (Hauteur > 0)//On s'assure qu'elle est plus que 0
    {
        dessinerLosange;//Puis on passe au dessiner losange 
    }
    else//Sinon 
    {
        cout << "Erreur veuillez entrer un chiffre raisonnable ";//On affiche ce message d'erreur 
        return Hauteur;//Puis on retourne la hauteur 
    }

    return 0;
}

void dessinerCarre() //J'ai commencer par dessiner le carre 
{
    int Hauteur = 0;//J'indique que la hauteur et la largeur est �gale a 0 pour 
    int Largeur = 0;// que le programme prenne les choix entrer par l'utilisateur 
    int choixRemplissage = 0;//M�me chose pour le choix du remplissage 
    choixRemplissage = afficherMenu2(choixRemplissage);

    if (afficherMenu2(choixRemplissage) == 1) //Pour commencer le carre doit faire deux if pour v�rifier si c'est plein ou vide 
    {
        for (int X = 0; X < Hauteur; X++) 
        {
            for (int Y = 0; Y <= Hauteur; Y++)
            {
         

                if (X != 0 && X != (Hauteur - 1))
                {

                    if (Y == 0 || Y == (Hauteur - 1))
                    {
                        std::cout << "*";   //Encore une fois ici ceci va �tre le contour
                    }
                    else
                    {
                        std::cout << "#";  //et l'int�rieur Ici 
                    }
                }
                else {

                    cout << "*";
                }

            }
            cout << endl;
        }
        cout << endl;
    }
    if (afficherMenu2(choixRemplissage) == 2) // m�me chose mais pour le choix num�ro deux donc si l'utilisateur le veux vide 
    {
        for (int X = 1; X <= Hauteur; X++)
        {
            for (int Y = 1; Y < Largeur; Y++)
            {
                if (X == 1 || Y == X || X == Hauteur || Y == Largeur)
                {
                    std::cout << "*";
                }
                else
                {
                    std::cout << " "; // Interieur vide 
                }

            }


        }
    }





}

void dessinerRectangle()
{
    int Hauteur = 0;//J'indique que la hauteur et la largeur est �gale a 0 pour 
    int Largeur = 0;// que le programme prenne les choix entrer par l'utilisateur 
    int choixRemplissage = 0;//M�me chose pour le choix du remplissage 
    choixRemplissage = afficherMenu2(choixRemplissage);
    if (afficherMenu2(choixRemplissage) == 1)//On commence encore par faire un if pour voir si l'utilisateur a choisis plein ici
    {

        for (int X = 0; X < Hauteur; X++)//Ici on fait une boucke for pour le rectangle 
        {
            for (int Y = 0; Y <= Largeur; Y++)//j'ai utiliser X et Y pour chacun des c�t�s pusique c'est plus simple a comprendre
            {
                if (X != 0 && X != (Hauteur - 1))
                {

                    if (Y == 0 || Y == (Largeur - 1))
                    {
                        std::cout << "*";//Pour les c�t�s on mets des �toiles comme demander 
                    }
                    else
                    {
                        std::cout << "#";//Ce qui va s,afficher a l'int�rieur pour remplir 
                    }
                }
                else {

                    cout << "*";
                }

            }
            cout << endl;
        }
        cout << endl;
    }

    if (afficherMenu2(choixRemplissage) == 2)
    {
        for (int X = 0; X < Hauteur; X++)
        {
            for (int Y = 0; Y <= Largeur; Y++)
            {      

                if (X != 0 && X != (Hauteur - 1))
                {

                    if (Y == 0 || Y == (Largeur - 1))
                    {
                        std::cout << "*"; // Les contours son tout pareils avec les etoiles donc on garde les boucles pareils 
                    }
                    else
                    {
                        std::cout << " "; //ici vu que c,est la forme vide au lieu de mettre # on fais simplement un espace 
                    }
                }
                else {

                    cout << "*";
                }

            }
            cout << endl;
        }
        cout << endl;

    }
}


void dessinerTriangle1()
{

    int Hauteur = 0; //hauteur est egale a 0 pour qu'on prend le choix de l'utilisateur 
    int choixRemplissage = 0;//M�me chose pour le choix du remplissage
    choixRemplissage = afficherMenu2(choixRemplissage);

    if (afficherMenu2(choixRemplissage) == 1)
    {
        for (int X = 1; X <= Hauteur; X++)
        {
            for (int Y = 1; Y <= X; Y++)
            {
                if (Y == 1 || Y == X || X == Hauteur || Y == Hauteur||X==0)
                {
                    std::cout << "*"; //contour comme les autres 
                }
                else
                {
                    std::cout << "#"; //Interieur avec des #
                }

            }
            std::cout << endl;
        }

        std::cout << endl;
    }
    if (afficherMenu2(choixRemplissage) == 2)
    {
        for (int X = 1; X <= Hauteur; X++)
        {
            for (int Y = 1; Y <= X; Y++)
            {
                if (Y == 1 || Y == X || X == Hauteur || Y == Hauteur|| X==0)
                {
                    std::cout << "*";
                }
                else
                {
                    std::cout << " ";
                }

            }
            std::cout << endl;
        }

        std::cout << endl;
    }
}

void dessinerLosange()
{
    int Hauteur = 0;
    int choixRemplissage = 0;
    choixRemplissage = afficherMenu2(choixRemplissage);
    
    if (afficherMenu2(choixRemplissage) == 1) //Si l'utilisateur le veux pleins
    {   // Pour le losanges on va avoir deux tr�s grande boucle for
        //Pusique on place 4 triangles ensemble deux en haut et deux en bas coller  ensemble
        //Donc on a pas besoin de demander la largeur juste la hauteur 
        //comme avec le triangle 
       
        for (int X = 0; X < Hauteur-1; X++)
        {
            for (int Y = 0; Y < Hauteur; Y++)
            {
                if (X < Hauteur - Y)
                {
                    cout << " ";
                }
                else
                {
                    cout << "*";
                }
            }
            for (int Y = 0; Y < X-1; Y++)
            {
                cout << "*";
            }
            cout << endl;
        }
        //En bas : Pour les deux triangles en bas maintanent 
        for (int X = Hauteur; X >= 1; X--)
        {
            for (int Y = 0; Y < Hauteur; Y++)
            {
                if (Y < Hauteur - X)
                {
                    cout << " ";
                }
                else
                {
                    cout << "*";
                }
            }
            for (int Y = 0; Y < X-1; Y++)
            {
                cout << "*";
            }
            cout << endl;


        }

    }
    if (afficherMenu2(choixRemplissage) == 2) //Si l'utilisateur le veux vide 
    {  
        //En haut //////////////////////////eu de la difficulter avec le losange vide .... donc marche pas////////////////////////////
        for (int X = 0; X < Hauteur - 1; X++)
        {
            for (int Y = 0; Y < Hauteur; Y++)
            {
                if (X < Hauteur - Y)
                {
                    cout << " ";
                }
                else
                {
                    cout << " ";
                }
            }
            for (int Y = 0; Y < X - 1; Y++)
            {
                cout << "*";
            }
            cout << endl;
        }
        //En bas
        for (int X = Hauteur; X >= 1; X--)
        {
            for (int Y = 0; Y < Hauteur; Y++)
            {
                if (Y < Hauteur - X)
                {
                    cout << " ";
                }
                else
                {
                    cout << " ";
                }
            }
            for (int Y = 0; Y < X - 1; Y++)
            {
                cout << "*";
            }
            cout << endl;


        }

    }








}
