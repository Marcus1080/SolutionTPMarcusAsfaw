#pragma once

//But : Votre petit cousin est fascin� par les formes g�om�triques. A chaque fois que vous le rencontrez, il vous demande
//de lui dessiner des carr�s, des rectangles, des triangles, des losanges.Quelques fois, il les veut plein, d�autres fois
//vides, il les veut de tailles diff�rentes, des petits, des gros.Vous d�cidez d��crire un programme en C++ qui r�pondra
//� tous les caprices de votre petit cousin et qu�enfin vous retrouviez un peu la paix !
//Auteur : Marcus Asfaw
//Date : Le 17 Novembre 2020 (date de remise)


int traiterRectangle(int Hauteur, int Largeur); //Fonction pour chaque forme j'utilise cves fonctions pour demande a l'utilisateur 
int traiterCarre(int Hauteur); //La hauteur et la largeur de la forme qu'il d�sire avant de dessiner la forme 
int traiterTriangle(int Hauteur);
int traiterLosange(int Hauteur);


void dessinerCarre(); //Fonction qui dessine le carre qui l'affiche a l'ecran
void dessinerRectangle(); //: Fonction qui dessine un rectangle ou un carr� dont la hauteur, la largeur et le mode de remplissage sont pass�s en param�tre.
void dessinerTriangle1(); //: Fonction qui dessine un triangle dans la position 1 dont la hauteur et le mode de remplissage sont pass�s en param�tre.
void dessinerLosange(); //: Fonction qui dessine un losange dont la hauteur et le mode de remplissage sont pass�s en param�tre.

/* pas eu le temps de toute faire mes triangles 
* 
* 
dessinerTriangle2(); //: Fonction qui dessine un triangle dans la position 2 dont la hauteur et le mode de remplissage sont pass�s en param�tre.
dessinerTriangle3(); //: Fonction qui dessine un triangle dans la position 3 dont la hauteur et le mode de remplissage sont pass�s en param�tre.
dessinerTriangle4(); //: Fonction qui dessine un triangle dans la position 4 dont la hauteur et le mode de remplissage sont pass�s en param�tre.


genererNombreAleatoire() //: Fonction qui retourne un nombre al�atoire compris entre min et max pass�s enparam�tre. */