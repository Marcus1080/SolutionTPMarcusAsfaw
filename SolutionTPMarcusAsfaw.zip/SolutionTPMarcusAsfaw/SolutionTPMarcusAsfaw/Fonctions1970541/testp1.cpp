#include<iostream>



using namespace std;








int main()
{
    int Hauteur = 5;

    for (int X = 0; X < Hauteur - 1; X++)
    {
        for (int Y = 0; Y < Hauteur; Y++)
        {
            if (X < Hauteur - Y)
            {
                cout << " ";
            }
            else
            {
                cout << "*";
            }
        }
        for (int Y = 0; Y < X - 1; Y++)
        {
            cout << "*";
        }
        cout << endl;
    }
    //En bas
    for (int X = Hauteur; X >= 1; X--)
    {
        for (int Y = 0; Y < Hauteur; Y++)
        {
            if (Y < Hauteur - X)
            {
                cout << " ";
            }
            else
            {
                cout << "*";
            }
        }
        for (int Y = 0; Y < X - 1; Y++)
        {
            cout << "*";
        }
        cout << endl;


    }
}