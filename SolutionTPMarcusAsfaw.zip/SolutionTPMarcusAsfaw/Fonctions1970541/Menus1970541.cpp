//But : Votre petit cousin est fascin� par les formes g�om�triques. A chaque fois que vous le rencontrez, il vous demande
//de lui dessiner des carr�s, des rectangles, des triangles, des losanges.Quelques fois, il les veut plein, d�autres fois
//vides, il les veut de tailles diff�rentes, des petits, des gros.Vous d�cidez d��crire un programme en C++ qui r�pondra
//� tous les caprices de votre petit cousin et qu�enfin vous retrouviez un peu la paix !
//Auteur : Marcus Asfaw
//Date : Le 17 Novembre 2020 (date de remise)


#include "Menus1970541.h"
#include<string>
#include <iostream>

// D�finition des constantes 

using namespace std;


 const int QUITTER = 5;     // Le choix maximum dans le menu 1. Pourrait changer si le programmeur ajoute une forme supppl�mentaire 
const int RETOUR = 3;     // Le choix maximum dans le menu 2. Pourrait changer si le programmeur ajoute une option supppl�mentaire
int choixForme;         //Le choix que l'utilisateur doit faire pour le premier menu (compris entre 1 et 5)
const int RECTANGLE = 1;     // Pour faciliter la lecture du code dans le switch
const int TRIANGLE = 2;
const int CARRE = 3;
const int LOSANGE = 4;

int afficherMenu(int choixForme)//Ici on commence le premier menu on ajoute le int choixForme pour le chjoix de l'utilisateur
{
    //Voici le menu qui est sens� appara�tre au d�but du programme
    //Qui fini par le cin de choixFrome pour le choix
    cout << "Bienvenue au programme ! Veuillez faire un choix! :  " << endl;
    cout << "1. Rectangle " << endl;
    cout << "2. Triangle " << endl;
    cout << "3. Carre " << endl;
    cout << "4. Losange " << endl;
    cout << "5. Quitter " << endl;
    cout << "Votre choix --> ";
    cin >> choixForme;

    while (choixForme < 1 || choixForme > 5)
    {
        validerMenu;
    }

    if (choixForme == 5)//Si l'utilisateur d�sire quitter le programme (le choix 5) 
    {
        system("pause");//On fait une pause
        system("cls");//On efface l'�cran
        return 0;//Et on sort du programme 
    }

    while (choixForme >= 1 || choixForme <= 5)//Ici si l'utilisateur entre un chiffre compris entre les choix 
    {
        afficherMenu2;//On passe au prochain menu qui est afficherMenu2
    }



    return choixForme;
 
}

int afficherMenu2(int choixRemplissage)//Ici on part le deuxi�me menu on fais un int Remplissage pour le choix de l'utilisateur 
{
    
   
    system("cls");//On efface l'�cran pour que sa sois plus propre
    cout << "1. Forme pleine " << endl;//On affiche les options pour le plein ou le vide
    cout << "2. Forme vide " << endl;
    cout << "3. Retourner au menu precedent" << endl;//Aussi une option pour retourner en arri�re 
    cout << "Votre choix --> ";
    cin >> choixRemplissage;//Un cin pour le choix fais 

    while (choixRemplissage <= 0 && choixRemplissage >= 3)//Ici on fait un while pour si le choix fait n'est pas compris entre 1 et 3 
    {
        validerMenu;
    }

    if (choixRemplissage == 3)//Si l'utilisateur choisi de retourner en arri�re 
    {
        afficherMenu;//On retourne au affichermenu donc au premier menu 

    }

    
    return choixRemplissage;
    
}


int validerMenu()
{


    while (afficherMenu(choixForme) < 1 || afficherMenu(choixForme) > 5)// Ici si l'utlisateur donne un chiffre pas compris entre les choix 
    {
        cout << "Veuillez entrer un chiffre compris entre 1 et 5 " << endl;// On affiche ce message d'erreur 
        system("pause");//Suivi d'un system pause et clear screen
        system("cls");
        afficherMenu;// Puis on affiche le menu du d�but 

    }





    
    return 0;
}
